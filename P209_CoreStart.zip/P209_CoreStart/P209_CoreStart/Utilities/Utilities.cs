﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;

namespace P209_CoreStart.Utilities
{
    public static class Utilities
    {
        public static void Remove(string root, string file)
        {
            string path = Path.Combine(root, "images", file);

            if(File.Exists(path))
            {
                File.Delete(path);
            }
        }
    }
}
