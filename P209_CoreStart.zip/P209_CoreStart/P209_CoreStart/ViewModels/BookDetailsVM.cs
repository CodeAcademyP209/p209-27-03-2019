﻿using P209_CoreStart.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P209_CoreStart.ViewModels
{
    public class BookDetailsVM
    {
        public Book Book { get; set; }
        public IEnumerable<Book> RelatedBooks { get; set; }
    }
}
