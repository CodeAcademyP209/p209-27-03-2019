﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace P209_CoreStart.Models
{
    public class Category
    {
        public Category()
        {
            Books = new HashSet<Book>();
        }

        public int Id { get; set; }

        [StringLength(100)]
        [Required]
        public string Name { get; set; }

        public virtual ICollection<Book> Books { get; set; }
    }
}
