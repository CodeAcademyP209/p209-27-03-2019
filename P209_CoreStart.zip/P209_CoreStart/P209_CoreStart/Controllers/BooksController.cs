﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using P209_CoreStart.Models;
using P209_CoreStart.ViewModels;
using P209_CoreStart.Data;
using P209_CoreStart.Extensions;
using static P209_CoreStart.Utilities.Utilities;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;

namespace P209_CoreStart.Controllers
{
    public class BooksController : Controller
    {
        private readonly BookContext _context;
        private readonly IHostingEnvironment _env;

        [BindProperty]
        public Book book { get; set; }

        public BooksController(BookContext context, IHostingEnvironment env)
        {
            _context = context;
            _env = env;
        }

        public IActionResult Details(int? id)
        {
            if (id == null) return NotFound();

            var book = _context.Books.Find(id);

            if (book == null) return NotFound();

            var vm = new BookDetailsVM
            {
                Book = book,
                RelatedBooks = _context.Books.Where(b => b.CategoryId == book.Category.Id && b.Id != book.Id).ToList()
            };

            return View(vm);
        }   

        public IActionResult Create()
        {
            ViewBag.Categories = _context.Categories;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("Create")]
        public async Task<IActionResult> CreatePost()
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Categories = _context.Categories;
                return View(book);
            }

            if(book.Photo == null)
            {
                ModelState.AddModelError("Photo", "Photo should be selected.");
                ViewBag.Categories = _context.Categories;
                return View(book);
            }

            if(!book.Photo.IsImage())
            {
                ModelState.AddModelError("Photo", "Photo type is not valid.");
                ViewBag.Categories = _context.Categories;
                return View(book);
            }

            book.Image = await book.Photo.SaveAsync(_env.WebRootPath, "books");

            _context.Books.Add(book);
            await _context.SaveChangesAsync();

            return RedirectToAction("Index", "Home");
        }

        public IActionResult Edit(int? id)
        {
            if (id == null) return NotFound();

            book = _context.Books.Find(id);

            if (book == null) return NotFound();

            ViewBag.Categories = _context.Categories;
            return View(book);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Categories = _context.Categories;
                return View(book);
            }

            var bookFromDb = _context.Books.Find(id);

            if(book.Photo != null)
            {
                if (!book.Photo.IsImage())
                {
                    ModelState.AddModelError("Photo", "Photo is not valid.");
                    ViewBag.Categories = _context.Categories;
                    book.Image = bookFromDb.Image;
                    return View(book);
                }

                //remove old
                Remove(_env.WebRootPath, bookFromDb.Image);
                //save new
                bookFromDb.Image = await book.Photo.SaveAsync(_env.WebRootPath, "books");
            }

            bookFromDb.Name = book.Name;
            bookFromDb.CategoryId = book.CategoryId;

            await _context.SaveChangesAsync();
            return RedirectToAction("Index", "Home");
        }

        public IActionResult Delete(int? id)
        {
            if (id == null) return NotFound();

            var book = _context.Books.Find(id);

            if (book == null) return NotFound();

            return View(book);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("Delete")]
        public async Task<IActionResult> DeletePost(int? id)
        {
            var bookFromDb = _context.Books.Find(id);
            Remove(_env.WebRootPath, bookFromDb.Image);
            _context.Books.Remove(bookFromDb);
            await _context.SaveChangesAsync();

            return RedirectToAction("Index", "Home");
        }
    }
}