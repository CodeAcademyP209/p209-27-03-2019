﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using P209_CoreStart.Data;

namespace P209_CoreStart.Controllers
{
    public class DemoController : Controller
    {
        private readonly RandomGenerator _randomGenerator;

        public DemoController(RandomGenerator randomGenerator)
        {
            _randomGenerator = randomGenerator;
        }

        public IActionResult Index()
        {
            ViewBag.Number = _randomGenerator.Number;
            return View();
        }
    }
}