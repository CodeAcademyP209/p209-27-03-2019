﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using P209_CoreStart.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P209_CoreStart.ViewComponents
{
    public class RelatedBooksViewComponent : ViewComponent
    {
        private readonly BookContext _context;

        public RelatedBooksViewComponent(BookContext context)
        {
            _context = context;
        }

        public async Task<IViewComponentResult> InvokeAsync(int bookId, int categoryId)
        {
            var books = await _context.Books.Where(b => b.CategoryId == categoryId && b.Id != bookId).ToListAsync();
            return View(books);
        }
    }
}
