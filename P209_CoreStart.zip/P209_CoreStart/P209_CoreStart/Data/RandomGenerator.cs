﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P209_CoreStart.Data
{
    public class RandomGenerator
    {
        public int Number { get; set; }
        Random random;

        public RandomGenerator(int a)
        {
            random = new Random();
            Number = random.Next(1, 100000);
        }
    }
}
